/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thedaggerforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.thedaggerforge.item.TheDaggerItem;
import net.mcreator.thedaggerforge.ThedaggerforgeMod;

public class ThedaggerforgeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ThedaggerforgeMod.MODID);
	public static final RegistryObject<Item> THE_DAGGER;
	static {
		THE_DAGGER = REGISTRY.register("the_dagger", TheDaggerItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}